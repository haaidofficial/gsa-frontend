import AnnualReturnComp from "@/components/AnnualReturn";

const AnnualReturn = () => {

    return (
        <>
            <AnnualReturnComp />
        </>
    )
}

export default AnnualReturn;