import ContactUsComp from "@/components/Contact";

const ContactUs = () => {

    return (
        <>
            <ContactUsComp />
        </>
    )
}

export default ContactUs;