import IndustriesComp from "@/components/Industries";

const Industries = () => {


    return (
        <>
          <IndustriesComp/>
        </>
    )
}

export default Industries;