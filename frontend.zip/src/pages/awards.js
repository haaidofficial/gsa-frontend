import AwardsComp from "@/components/Awards";

const Awards = () => {

    return (
        <>
            <AwardsComp />
        </>
    )
}

export default Awards;