import LicencesComp from "@/components/Licences";

const Licences = () => {

    return (
        <>
            <LicencesComp />
        </>
    )
}

export default Licences;