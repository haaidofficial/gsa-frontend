import AboutUsComp from "@/components/AboutUs";

const AboutUs = () => {

    return (
        <>
        <AboutUsComp/>
        </>
    )
}

export default AboutUs;